import org.testng.annotations.Test;
import page.CheckoutPage;

import static org.testng.Assert.assertTrue;


public class HealeniumTest extends BaseTest {

    @Test
    public void testCheckoutWithAllFields() throws InterruptedException {
        new CheckoutPage(driver)
                .inputFirstName("Osanda")
                .inputLastName("Nimalarathna")
                .inputUsername("osanda")
                .inputEmail("osanda@mailinator.com")
                .inputAddress1("Poramba")
                .inputAddress2("Ambalangoda")
				/*
				 * .selectCountry("United States") .selectState("California")
				 * .inputZip("90000CF")
				 */
                .timeHold()
               // .inputCreditCardName("Osanda Nimalarathna")
               // .inputCreditCardNumber("1234567890123456")
                //.inputCreditCardExpiration("12/23")
               /* .timeHold()
                .inputCreditCardCvv("123")
                .timeHold()
                .clickCheckoutButton()*/
                ;
        try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       // assertTrue(driver.getCurrentUrl().contains("paymentMethod=on"), "Checkout failed!");
    }
}
